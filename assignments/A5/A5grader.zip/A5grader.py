use_my_solution = True

import pandas
import os
import copy
import numpy as np

print('\n======================= Code Execution =======================\n')

assignmentNumber = '5'


if use_my_solution:
    from A5mysolution import *
    print("RUNNING INSTRUCTOR's SOLUTION!!!!!!!!!!!!")

else:
    import subprocess, glob, pathlib
    # nb_name = '*-A[0-9]*{,-?}.ipynb'
    nb_name = '*[-_]A[0-9]*.ipynb'
    # nb_name = '*.ipynb'
    try:
        filename = next(glob.iglob(nb_name.format(assignmentNumber)), None)
    except:
        nb_name = '*[-_]A[0-9]*-?.ipynb'
        filename = next(glob.iglob(nb_name.format(assignmentNumber)), None)
    print('Extracting python code from notebook named \'{}\' and storing in notebookcode.py'.format(filename))
    if not filename:
        raise Exception('Please rename your notebook file to <Your Last Name>-A{}.ipynb'.format(assignmentNumber))
    with open('notebookcode.py', 'w') as outputFile:
        subprocess.call(['jupyter', 'nbconvert', '--to', 'script',
                         nb_name.format(assignmentNumber), '--stdout'], stdout=outputFile)
        # from https://stackoverflow.com/questions/30133278/import-only-functions-from-a-python-file
    import sys
    import ast
    import types
    with open('notebookcode.py') as fp:
        tree = ast.parse(fp.read(), 'eval')
        print('Removing all statements that are not function or class defs or import statements.')
    for node in tree.body[:]:
        if (not isinstance(node, ast.FunctionDef) and
            not isinstance(node, ast.ClassDef) and
            not isinstance(node, ast.Import)):  #  and
            # not isinstance(node, ast.ImportFrom)):
            tree.body.remove(node)
            # Now write remaining code to py file and import it
    module = types.ModuleType('notebookcodeStripped')
    code = compile(tree, 'notebookcodeStripped.py', 'exec')
    sys.modules['notebookcodeStripped'] = module
    exec(code, module.__dict__)
    # import notebookcodeStripped as useThisCode
    from notebookcodeStripped import *



exec_grade = 0

# for func in ['NeuralNetworkClassifier']:
#     if func not in dir() or not callable(globals()[func]):
#         print('CRITICAL ERROR: Function or class named \'{}\' is not defined'.format(func))
#         print('  Check the spelling and capitalization of the function or class name.')

# for func in ['Tmeans', 'Tstds', 'Vs', 'W', 'Xmeans', 'Xstds', '__repr__',
#              '_forward_pass', '_gradientF', '_objectiveF', '_objective_to_actual',
#              '_pack', '_setup_standardize', '_standardizeT', '_standardizeX',
#              '_unpack', '_unstandardizeT', '_unstandardizeX', 'classes',
#              'draw', 'error_trace', 'exp', 'get_error_trace', 'get_n_epochs',
#              'get_training_time', 'get_weight_history', 'log', 'mean',
#              'n_epochs', 'n_hidden_layers', 'n_hiddens_list', 'n_inputs',
#              'n_outputs', 'reason', 'sqrt', 'tanh', 'train',
#              'training_time', 'use', 'use_torch']:
#     nnet = NeuralNetworkClassifier(1, [10], [0, 1])
#     if func not in dir(nnet):
#         print('CRITICAL ERROR: Function named \'{}\' is not defined in your NeuralNetworkClassifier class'.format(func))
#         print('  Check the spelling and capitalization of the function or class name.')
        



######################################################################

print('''
######################################################################
Testing

s = initialState(6.6)
''')
      
try:
    pts = 20
    s = initialState(6.6)
    if s[2] == 6.6:
        exec_grade += pts
        print(f'\n--- {pts}/{pts} points. initialState correctly returns goal of 6.6 as third component.')
    else:
        print(f'\n---  0/{pts} points. initialState returned incorrect value as third argument of {s[2]}.')
except Exception as ex:
    print(f'\n--- 0/{pts} points. raised the exception\n')
    print(ex)


######################################################################

print('''
######################################################################
Testing

r = reinforcement(np.array([2.8, 2, 3]), np.array([3.6, 1, 3]))
''')
      
try:
    pts = 20
    r = reinforcement(np.array([2.8, 2, 3]), np.array([3.6, 1, 3]))
    if r == 0:
        exec_grade += pts
        print(f'\n--- {pts}/{pts} points. reinforcement correctly returns 0.')
    else:
        print(f'\n---  0/{pts} points. reinforcement returned {r} but should return 0.')
except Exception as ex:
    print(f'\n--- 0/{pts} points. raised the exception\n')
    print(ex)


print('''
######################################################################
Testing

r = reinforcement(np.array([7., 2., 3.]), np.array([8., 1., 3.]))
''')
      
try:
    pts = 20
    r = reinforcement(np.array([7., 2., 3.]), np.array([8., 1., 3.]))
    if r == -1:
        exec_grade += pts
        print(f'\n--- {pts}/{pts} points. reinforcement correctly returns -1.')
    else:
        print(f'\n---  0/{pts} points. reinforcement returned {r} but should return -1.')
except Exception as ex:
    print(f'\n--- 0/{pts} points. raised the exception\n')
    print(ex)

    

######################################################################

print('''
######################################################################
Testing

s_next = nextState(np.array([1.0, 0.0, 7.0]), 1.0)

''')
      
try:
    pts = 10
    s_next = nextState(np.array([1.0, 0.0, 7.0]), 1.0)
    if s_next[1] > 0 and s_next[2] == 7:
        exec_grade += pts
        print(f'\n--- {pts}/{pts} points. nextState correctly returns new state with velociy > 0 and goal of 7.')
    else:
        print(f'\n---  0/{pts} points. nextState returns velocity that incorrectly is not > 0 or with goal that is not 7.')
except Exception as ex:
    print(f'\n--- 0/{pts} points. raised the exception\n')
    print(ex)



name = os.getcwd().split('/')[-1]

print()
print('='*70)
print('{} Execution Grade is {} / 70'.format(name, exec_grade))
print('='*70)

print('''\n __ / 10 You correctly plot 9 versions of the testIt plot for different goals.''')
print('''\n __ / 10 You show several versions of the contour and surface plots for goals of 1, 5 and 9.''')
print('''\n __ / 10 You show results of trying variety of parameters values to get best results
         and you discuss the results.''')


print()
print('='*70)
print('{} FINAL GRADE is  _  / 100'.format(name))
print('='*70)

print('''
Extra Credit:
1. Change the marble's world from one dimension to two. Add graphs of the marble's movement in the two-dimensional plane.
2. Increase the number of valid actions from three to seven and discuss the difference between the required runs and these new runs.
3. Add a variable wind as a force on the marble, along with another state variable that indicates wind speed and direction.
4. Add a second marble with its own RL agent. Add negative reinforcement if they bump into each other.
5. Add areas of increased friction to the track.''')

print('\n{} EXTRA CREDIT is 0 / 2'.format(name))

if use_my_solution:
    print("RUNNING INSTRUCTOR's SOLUTION!!!!!!!!!!!!")
