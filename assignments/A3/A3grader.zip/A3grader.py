use_my_solution = True

import os
import copy
import signal

# Code to limit running time of specific parts of code.
#  To use, do this for example...
#
#  signal.alarm(seconds)
#  try:
#    ... run this ...
#  except TimeoutException:
#     print(' 0/8 points. Your depthFirstSearch did not terminate in', seconds/60, 'minutes.')
# Exception to signal exceeding time limit.


# class TimeoutException(Exception):
#     def __init__(self, *args, **kwargs):
#         Exception.__init__(self, *args, **kwargs)


# def timeout(signum, frame):
#     raise TimeoutException

# seconds = 60 * 5

# Comment next line for Python2
# signal.signal(signal.SIGALRM, timeout)

import os
import numpy as np

print('\n======================= Code Execution =======================\n')

assignmentNumber = '3'


if use_my_solution:
    from monmy import *
    # from A3mysolution import *
    print("RUNNING INSTRUCTOR's SOLUTION!!!!!!!!!!!!")

else:
    import subprocess, glob, pathlib
    # nb_name = '*-A[0-9]*{,-?}.ipynb'
    nb_name = '*[-_]A[0-9]*.ipynb'
    # nb_name = '*.ipynb'
    try:
        filename = next(glob.iglob(nb_name.format(assignmentNumber)), None)
    except:
        nb_name = '*[-_]A[0-9]*-?.ipynb'
        filename = next(glob.iglob(nb_name.format(assignmentNumber)), None)
    print('Extracting python code from notebook named \'{}\' and storing in notebookcode.py'.format(filename))
    if not filename:
        raise Exception('Please rename your notebook file to <Your Last Name>-A{}.ipynb'.format(assignmentNumber))
    with open('notebookcode.py', 'w') as outputFile:
        subprocess.call(['jupyter', 'nbconvert', '--to', 'script',
                         nb_name.format(assignmentNumber), '--stdout'], stdout=outputFile)
        # from https://stackoverflow.com/questions/30133278/import-only-functions-from-a-python-file
    import sys
    import ast
    import types
    with open('notebookcode.py') as fp:
        tree = ast.parse(fp.read(), 'eval')
        print('Removing all statements that are not function or class defs or import statements.')
    for node in tree.body[:]:
        if (not isinstance(node, ast.FunctionDef) and
            not isinstance(node, ast.ClassDef) and
            not isinstance(node, ast.Import)):  #  and
            # not isinstance(node, ast.ImportFrom)):
            tree.body.remove(node)
            # Now write remaining code to py file and import it
    module = types.ModuleType('notebookcodeStripped')
    code = compile(tree, 'notebookcodeStripped.py', 'exec')
    sys.modules['notebookcodeStripped'] = module
    exec(code, module.__dict__)
    # import notebookcodeStripped as useThisCode
    from notebookcodeStripped import *



exec_grade = 0

for func in ['NeuralNetworkClassifier']:
    if func not in dir() or not callable(globals()[func]):
        print('CRITICAL ERROR: Function or class named \'{}\' is not defined'.format(func))
        print('  Check the spelling and capitalization of the function or class name.')

for func in ['Tmeans', 'Tstds', 'Vs', 'W', 'Xmeans', 'Xstds', '__repr__',
             '_forward_pass', '_gradientF', '_objectiveF', '_objective_to_actual',
             '_pack', '_setup_standardize', '_standardizeT', '_standardizeX',
             '_unpack', '_unstandardizeT', '_unstandardizeX', 'classes',
             'draw', 'error_trace', 'exp', 'get_error_trace', 'get_n_epochs',
             'get_training_time', 'get_weight_history', 'log', 'mean',
             'n_epochs', 'n_hidden_layers', 'n_hiddens_list', 'n_inputs',
             'n_outputs', 'reason', 'sqrt', 'tanh', 'train',
             'training_time', 'use', 'use_torch']:
    nnet = NeuralNetworkClassifier(1, [10], [0, 1])
    if func not in dir(nnet):
        print('CRITICAL ERROR: Function named \'{}\' is not defined in your NeuralNetworkClassifier class'.format(func))
        print('  Check the spelling and capitalization of the function or class name.')
        


print('''\nTesting if your NeuralNetworkClassifier can learn to detect vowels when given
their ascii codes.

import numpy as np
ascii_code = list(range(65, 91)) + list(range(97, 123))
chars = [chr(n).lower() for n in ascii_code]
vowel = [c in ['a', 'e', 'i', 'o', 'u'] for c in chars]
X = np.array(ascii_code).reshape((-1, 1))
T = np.array(vowel).reshape((-1, 1))
classes = np.unique(T)

np.random.seed(120)
nnet = NeuralNetworkClassifier(X.shape[1], [50, 20, 20], classes)
nnet.train(X, T, 10000, verbose=True)
Yc, Y = nnet.use(X)
n_correct = (Yc == T).sum()
print(f'{n_correct} out of {T.shape[0]} samples, or {n_correct/T.shape[0]*100:.2f} percent.')''')

import numpy as np
ascii_code = list(range(65, 91)) + list(range(97, 123))
chars = [chr(n).lower() for n in ascii_code]
vowel = [c in ['a', 'e', 'i', 'o', 'u'] for c in chars]
X = np.array(ascii_code).reshape((-1, 1))
T = np.array(vowel).reshape((-1, 1))
classes = np.unique(T)

try:
    pts = 80
    np.random.seed(120)
    nnet = NeuralNetworkClassifier(X.shape[1], [50, 20, 20], classes)
    nnet.train(X, T, 10000, verbose=True)
    Yc, Y = nnet.use(X)
    n_correct = (Yc == T).sum()
    print(f'{n_correct} out of {T.shape[0]} samples, or {n_correct/T.shape[0]*100:.2f} percent.')
    correct_answer = 48
    if n_correct > 48:
        exec_grade += pts
        print(f'\n--- {pts}/{pts} points. Returned correct value of {n_correct}.')
    else:
        print(f'\n---  0/{pts} points. Returned incorrect value. n_correct should be {correct_answer}')
except Exception as ex:
    print(f'\n--- 0/{pts} points. raised the exception\n')
    print(ex)





name = os.getcwd().split('/')[-1]

print()
print('='*70)
print('{} Execution Grade is {} / 80'.format(name, exec_grade))
print('='*70)

print('''\n __ / 10 You obtained data for a classification problem and set up
         X and T matrices correctly.''')
print('''\n __ / 10 You compared several different network sizes, numbers of
         epochs, and optimization algoritms and described the results.''')

print()
print('='*70)
print('{} FINAL GRADE is  _  / 100'.format(name))
print('='*70)

print('''
Extra Credit:
1. For the data set you have downloaded, randomly partition the data into about
   80% for training and 20% for testing. Discuss the percent of samples correctly
   classified for train and test partitions and how variations in netowrk size, 
   epochs, and optimization algorithm effect the results.
2. Develop a new version of optimizers.py, neuralnetworks.py and your
   NeuralNetworkClassifier class that will run on a GPU using pytorch. 
   Add a keyword argument where neded called use_gpu that can be set to True to
   run on GPU.''')

print('\n{} EXTRA CREDIT is 0 / 2'.format(name))
