use_my_solution = True

import os
import copy
import signal

# Code to limit running time of specific parts of code.
#  To use, do this for example...
#
#  signal.alarm(seconds)
#  try:
#    ... run this ...
#  except TimeoutException:
#     print(' 0/8 points. Your depthFirstSearch did not terminate in', seconds/60, 'minutes.')
# Exception to signal exceeding time limit.


# class TimeoutException(Exception):
#     def __init__(self, *args, **kwargs):
#         Exception.__init__(self, *args, **kwargs)


# def timeout(signum, frame):
#     raise TimeoutException

# seconds = 60 * 5

# Comment next line for Python2
# signal.signal(signal.SIGALRM, timeout)

import os
import numpy as np

print('\n======================= Code Execution =======================\n')

assignmentNumber = '4'


if use_my_solution:
    from A4mysolution import *
    print("RUNNING INSTRUCTOR's SOLUTION!!!!!!!!!!!!")

else:
    import subprocess, glob, pathlib
    # nb_name = '*-A[0-9]*{,-?}.ipynb'
    nb_name = '*[-_]A[0-9]*.ipynb'
    # nb_name = '*.ipynb'
    try:
        filename = next(glob.iglob(nb_name.format(assignmentNumber)), None)
    except:
        nb_name = '*[-_]A[0-9]*-?.ipynb'
        filename = next(glob.iglob(nb_name.format(assignmentNumber)), None)
    print('Extracting python code from notebook named \'{}\' and storing in notebookcode.py'.format(filename))
    if not filename:
        raise Exception('Please rename your notebook file to <Your Last Name>-A{}.ipynb'.format(assignmentNumber))
    with open('notebookcode.py', 'w') as outputFile:
        subprocess.call(['jupyter', 'nbconvert', '--to', 'script',
                         nb_name.format(assignmentNumber), '--stdout'], stdout=outputFile)
        # from https://stackoverflow.com/questions/30133278/import-only-functions-from-a-python-file
    import sys
    import ast
    import types
    with open('notebookcode.py') as fp:
        tree = ast.parse(fp.read(), 'eval')
        print('Removing all statements that are not function or class defs or import statements.')
    for node in tree.body[:]:
        if (not isinstance(node, ast.FunctionDef) and
            not isinstance(node, ast.ClassDef) and
            not isinstance(node, ast.Import)):  #  and
            # not isinstance(node, ast.ImportFrom)):
            tree.body.remove(node)
            # Now write remaining code to py file and import it
    module = types.ModuleType('notebookcodeStripped')
    code = compile(tree, 'notebookcodeStripped.py', 'exec')
    sys.modules['notebookcodeStripped'] = module
    exec(code, module.__dict__)
    # import notebookcodeStripped as useThisCode
    from notebookcodeStripped import *



exec_grade = 0

for func in ['NeuralNetwork_Convolutional']:
    if func not in dir() or not callable(globals()[func]):
        print('CRITICAL ERROR: Function or class named \'{}\' is not defined'.format(func))
        print('  Check the spelling and capitalization of the function or class name.')

# for func in ['Tmeans', 'Tstds', 'Vs', 'W', 'Xmeans', 'Xstds', '__repr__',
#              '_forward_pass', '_gradientF', '_objectiveF', '_objective_to_actual',
#              '_pack', '_setup_standardize', '_standardizeT', '_standardizeX',
#              '_unpack', '_unstandardizeT', '_unstandardizeX', 'classes',
#              'draw', 'error_trace', 'exp', 'get_error_trace', 'get_n_epochs',
#              'get_training_time', 'get_weight_history', 'log', 'mean',
#              'n_epochs', 'n_hidden_layers', 'n_hiddens_list', 'n_inputs',
#              'n_outputs', 'reason', 'sqrt', 'tanh', 'train',
#              'training_time', 'use', 'use_torch']:
#     nnet = NeuralNetworkClassifier(1, [10], [0, 1])
#     if func not in dir(nnet):
#         print('CRITICAL ERROR: Function named \'{}\' is not defined in your NeuralNetworkClassifier class'.format(func))
#         print('  Check the spelling and capitalization of the function or class name.')
        


print('''\nTesting if your NeuralNetwork_Convolutional can learn to classify a small 
subset of hand_drawn 0, 1, and 2 digits.

import numpy as np
import pickle, gzip

# Load the dataset
with gzip.open('mnist.pkl.gz', 'rb') as f:
    train_set, valid_set, test_set = pickle.load(f, encoding='latin1')
Xtest = test_set[0]
traini = [3,  10,  13,  25,  28,  55,  69,  71, 101, 126, 2,   5,  14,  29,  31,  37,  39,  40,  46,  57, 1,  35,  38,  43,  47,  72,  77,  82, 106, 119]
testi = [136, 148, 157, 183, 188, 192, 194, 215, 246, 269,  74,  89,  94, 96, 107, 135, 137, 143, 145, 154, 147, 149, 172, 174, 186, 199, 208, 221, 222, 225]
Xtrain = test_set[0][traini, :].reshape(-1, 1, 28, 28)
Ttrain = test_set[1][traini].reshape(-1, 1)
Xtest = test_set[0][testi, :].reshape(-1, 1, 28, 28)
Ttest = test_set[1][testi].reshape(-1, 1)

torch.random.manual_seed(42)

nnet = NeuralNetwork_Convolutional(n_channels_in_image=Xtrain.shape[1],
                                   image_size=Xtrain.shape[2],
                                   n_units_in_conv_layers=[5, 5],
                                   conv_kernels=[[5, 3], [4, 2]],
                                   n_units_in_fc_hidden_layers=[10],
                                   classes=[0, 1, 2],
                                   use_gpu=False)

nnet.train(Xtrain, Ttrain, 20, learning_rate=0.01)
Yclasses, Y = nnet.use(Xtest)
n_correct = (Yclasses == Ttest).sum()
print(f'{n_correct} out of {Ttest.shape[0]} samples, or {n_correct/Ttest.shape[0]*100:.2f} percent.')
''')

import numpy as np
import pickle, gzip

# Load the dataset
with gzip.open('mnist.pkl.gz', 'rb') as f:
    train_set, valid_set, test_set = pickle.load(f, encoding='latin1')
Xtest = test_set[0]
traini = [3,  10,  13,  25,  28,  55,  69,  71, 101, 126, 2,   5,  14,  29,  31,  37,  39,  40,  46,  57, 1,  35,  38,  43,  47,  72,  77,  82, 106, 119]
testi = [136, 148, 157, 183, 188, 192, 194, 215, 246, 269,  74,  89,  94, 96, 107, 135, 137, 143, 145, 154, 147, 149, 172, 174, 186, 199, 208, 221, 222, 225]
Xtrain = test_set[0][traini, :].reshape(-1, 1, 28, 28)
Ttrain = test_set[1][traini].reshape(-1, 1)
Xtest = test_set[0][testi, :].reshape(-1, 1, 28, 28)
Ttest = test_set[1][testi].reshape(-1, 1)



try:
    pts = 80

    torch.random.manual_seed(42)
    nnet = NeuralNetwork_Convolutional(n_channels_in_image=Xtrain.shape[1],
                                       image_size=Xtrain.shape[2],
                                       n_units_in_conv_layers=[5, 5],
                                       kernels_size_and_stride=[[5, 3], [4, 2]],
                                       n_units_in_fc_hidden_layers=[10],
                                       classes=[0, 1, 2],
                                       use_gpu=False)

    nnet.train(Xtrain, Ttrain, 20, learning_rate=0.01)
    Yclasses, Y = nnet.use(Xtest)
    n_correct = (Yclasses == Ttest).sum()
    print(f'{n_correct} out of {Ttest.shape[0]} samples, or {n_correct/Ttest.shape[0]*100:.2f} percent.')
    correct_answer = 27
    if n_correct >= 25:
        exec_grade += pts
        print(f'\n--- {pts}/{pts} points. Returned correct value of {n_correct}.')
    else:
        print(f'\n---  0/{pts} points. Returned incorrect value. n_correct should be {correct_answer}')
except Exception as ex:
    print(f'\n--- 0/{pts} points. raised the exception\n')
    print(ex)


print('''\nTesting 
errors = nnet.get_error_trace()
''')

try:
    pts = 10

    errors = nnet.get_error_trace()
    if len(errors) == 20:
        exec_grade += pts
        print(f'\n--- {pts}/{pts} points. Returned correct number of errors in error_trace.')
    else:
        print(f'\n---  0/{pts} points. Returned incorrect number of errors in error_trace. Should be 20 errors.')
except Exception as ex:
    print(f'\n--- 0/{pts} points. raised the exception\n')
    print(ex)




name = os.getcwd().split('/')[-1]

print()
print('='*70)
print('{} Execution Grade is {} / 90'.format(name, exec_grade))
print('='*70)

print('''\n __ / 10 You show results for at least 10 different runs having various
values for number of layers, units, and epochs for modeling MNIST data.
You must show percent correct for train, validation and test sets for each run.
Discuss your results. ''')

print()
print('='*70)
print('{} FINAL GRADE is  _  / 100'.format(name))
print('='*70)

print('''
Extra Credit:
1. For one of your runs, display the output images of your convolutional layers 
   and the weights for those layers.  Discuss what you see.  Describe why the
   displayed weight patterns result in the output images of the first convolutional
   layer.
2. Make at least one of your runs on a workstation with a GPU and run with use_gpu=True.
   Also run it with use_gpu=False.  Discuss the differences in training times.''')

print('\n{} EXTRA CREDIT is 0 / 2'.format(name))

if use_my_solution:
    print('THIS WAS RUN WITH INSTRUCTORS SOLUTION!!!!')
