import os
import copy
import signal

# Code to limit running time of specific parts of code.
#  To use, do this for example...
#
#  signal.alarm(seconds)
#  try:
#    ... run this ...
#  except TimeoutException:
#     print(' 0/8 points. Your depthFirstSearch did not terminate in', seconds/60, 'minutes.')
# Exception to signal exceeding time limit.


# class TimeoutException(Exception):
#     def __init__(self, *args, **kwargs):
#         Exception.__init__(self, *args, **kwargs)


# def timeout(signum, frame):
#     raise TimeoutException

# seconds = 60 * 5

# Comment next line for Python2
# signal.signal(signal.SIGALRM, timeout)

import os
import numpy as np

print('\n======================= Code Execution =======================\n')

assignmentNumber = '2'

if False:
    from A2mysolution import *
    print("RUNNING INSTRUCTOR's SOLUTION!!!!!!!!!!!!")

else:
    import subprocess, glob, pathlib
    nb_name = '*[-_]A{}.ipynb'
    # nb_name = '*.ipynb'
    filename = next(glob.iglob(nb_name.format(assignmentNumber)), None)
    print('Extracting python code from notebook named \'{}\' and storing in notebookcode.py'.format(filename))
    if not filename:
        raise Exception('Please rename your notebook file to <Your Last Name>-A{}.ipynb'.format(assignmentNumber))
    with open('notebookcode.py', 'w') as outputFile:
        subprocess.call(['jupyter', 'nbconvert', '--to', 'script',
                         nb_name.format(assignmentNumber), '--stdout'], stdout=outputFile)
    # from https://stackoverflow.com/questions/30133278/import-only-functions-from-a-python-file
    import sys
    import ast
    import types
    with open('notebookcode.py') as fp:
        tree = ast.parse(fp.read(), 'eval')
    print('Removing all statements that are not function or class defs or import statements.')
    for node in tree.body[:]:
        if (not isinstance(node, ast.FunctionDef) and
            not isinstance(node, ast.Import)):  #  and
            # not isinstance(node, ast.ClassDef) and
            # not isinstance(node, ast.ImportFrom)):
            tree.body.remove(node)
    # Now write remaining code to py file and import it
    module = types.ModuleType('notebookcodeStripped')
    code = compile(tree, 'notebookcodeStripped.py', 'exec')
    sys.modules['notebookcodeStripped'] = module
    exec(code, module.__dict__)
    # import notebookcodeStripped as useThisCode
    from notebookcodeStripped import *



g = 0

for func in ['mse', 'network', 'error_gradient']:
    if func not in dir() or not callable(globals()[func]):
        print('CRITICAL ERROR: Function named \'{}\' is not defined'.format(func))
        print('  Check the spelling and capitalization of the function name.')


print('''\nTesting
X = np.arange(3 * 4).reshape((3, 4)) * 0.1
T = np.hstack(( np.sin(X[:, 0:1]) + X[:, 1:2],
                X[:, 2:3] * -0.5,
                X[:, 3:4] ** 2))
n_inputs = X.shape[1]
n_outputs = T.shape[1]
n_hiddens_1 = 6
n_hiddens_2 = 2
n_w = (n_inputs + 1) * n_hiddens_1 + (n_hiddens_1 + 1) * n_hiddens_2 + (n_hiddens_2 + 1) * n_outputs
w = (np.arange(n_w) - n_w/2) * 0.01
Y = network(w, n_inputs, n_hiddens_1, n_hiddens_2, n_outputs, X)
''')

X = np.arange(3 * 4).reshape((3, 4)) * 0.1
T = np.hstack(( np.sin(X[:, 0:1]) + X[:, 1:2],
                X[:, 2:3] * -0.5,
                X[:, 3:4] ** 2))
n_inputs = X.shape[1]
n_outputs = T.shape[1]
n_hiddens_1 = 6
n_hiddens_2 = 2
n_w = (n_inputs + 1) * n_hiddens_1 + (n_hiddens_1 + 1) * n_hiddens_2 + (n_hiddens_2 + 1) * n_outputs
w = (np.arange(n_w) - n_w/2) * 0.01

try:
    pts = 20
    Y = network(w, n_inputs, n_hiddens_1, n_hiddens_2, n_outputs, X)
    correct_Y = np.array([[0.12022254, 0.12773632, 0.13525011],
                               [0.08581156, 0.09176614, 0.09772072],
                               [0.05582873, 0.06042448, 0.06502022]])
    if np.allclose(Y, correct_Y, atol=1e-2):
        g += pts
        print(f'\n--- {pts}/{pts} points. Returned correct values.')
    else:
        print(f'\n---  0/{pts} points. Returned incorrect values. Y should be')
        print(correct_Y)
except Exception as ex:
    print(f'\n--- 0/{pts} points. network raised the exception\n')
    print(ex)


print('''\nTesting
Y, Z1, Z2 = network(w, n_inputs, n_hiddens_1, n_hiddens_2, n_outputs, X, all_outputs=True)
''')

try:
    pts = 20
    Y, Z1, Z2 = network(w, n_inputs, n_hiddens_1, n_hiddens_2, n_outputs, X,
                        all_outputs=True)
    correct_Y = np.array([[0.12022254, 0.12773632, 0.13525011],
                               [0.08581156, 0.09176614, 0.09772072],
                               [0.05582873, 0.06042448, 0.06502022]])
    correct_Z1 = np.array([[-0.29496888, -0.28029298, -0.26548486, -0.25055041, -0.23549575,
                            -0.22032722],
                           [-0.45262762, -0.4268185 , -0.40029486, -0.37308313, -0.34521403,
                            -0.31672254],
                           [-0.58629394, -0.55390692, -0.51975207, -0.4838508 , -0.44624361,
                            -0.40699138]])

    correct_Z2 = np.array([[-0.12161728, -0.12700392],
                           [-0.19596638, -0.20857586],
                           [-0.26095696, -0.27946846]])

    if (np.allclose(Y, correct_Y, atol=1e-2) and
        np.allclose(Z1, correct_Z1, atol=1e-2) and
        np.allclose(Z2, correct_Z2, atol=1e-2)):
        g += pts
        print(f'\n--- {pts}/{pts} points. Returned correct values.')
    else:
        print(f'\n---  0/{pts} points. Returned incorrect values.')
        print('Y should be')
        print(correct_Y)
        print('Z1 should be')
        print(correct_Z1)
        print('Z2 should be')
        print(correct_Z2)
        
except Exception as ex:
    print(f'\n--- 0/{pts} points. network raised the exception\n')
    print(ex)
    


print('''\nTesting
grad = error_gradient(w, n_inputs, n_hiddens_1, n_hiddens_2, n_outputs, X, T)
''')

try:
    pts = 20
    grad = error_gradient(w, n_inputs, n_hiddens_1, n_hiddens_2, n_outputs, X, T)
    correct_grad = np.array([-0.03012404, -0.0422688 , -0.0554566 , -0.0696381 , -0.08474055,
                             -0.1006668 , -0.02357841, -0.03300111, -0.04320276, -0.05414793,
                             -0.06578336, -0.07803717, -0.02659082, -0.03722799, -0.04874842,
                             -0.06111174, -0.07425742, -0.08810385, -0.02960322, -0.04145487,
                             -0.05429408, -0.06807555, -0.08273147, -0.09817053, -0.03261563,
                             -0.04568175, -0.05983974, -0.07503936, -0.09120553, -0.1082372 ,
                             -0.35069456, -0.39631011,  0.20325839,  0.22968744,  0.19187589,
                             0.21682381,  0.17991939,  0.2033118 ,  0.16739759,  0.18916124,
                             0.15432506,  0.1743886 ,  0.14072262,  0.15901741, -1.5632744 ,
                             0.78661796, -0.99467263,  0.37500796, -0.16714422,  0.24677387,
                             0.40096153, -0.17817156,  0.26403919])
    if np.allclose(grad, correct_grad, atol=1e-2):
        g += pts
        print(f'\n--- {pts}/{pts} points. Returned correct values.')
    else:
        print(f'\n---  0/{pts} points. Returned incorrect values.')
        print('grad should be')
        print(correct_grad)
        
except Exception as ex:
    print(f'\n--- 0/{pts} points. network raised the exception\n')
    print(ex)
    



print('''\nTesting
m = mse(w, n_inputs, n_hiddens_1, n_hiddens_2, n_outputs, X, T)
''')

try:
    pts = 20
    m = mse(w, n_inputs, n_hiddens_1, n_hiddens_2, n_outputs, X, T)
    correct_m = 0.5634322138186323
    if np.allclose(correct_m, m, atol=1e-2):
        g += pts
        print(f'\n--- {pts}/{pts} points. Returned correct values.')
    else:
        print(f'\n---  0/{pts} points. Returned incorrect values.')
        print('m should be')
        print(correct_m)
        
except Exception as ex:
    print(f'\n--- 0/{pts} points. network raised the exception\n')
    print(ex)
    

name = os.getcwd().split('/')[-1]

print('\n{} Execution Grade is {} / 80'.format(name, g))

print('''
Your final assignment grade will be based on other tests.  Run additional tests
of your own design to check your functions before checking in this notebook.''')

print('\n{} FINAL GRADE is ___ / 100'.format(name))

# print('\n{} EXTRA CREDIT is   / 1'.format(name))

